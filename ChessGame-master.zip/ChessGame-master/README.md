# ChessGame
This is a game of chess with a graphical user interface and was made in C++ using the SFML libraries for my Programming Strand in Term 2 of Year 1 of my studies at Nottingham Trent University
