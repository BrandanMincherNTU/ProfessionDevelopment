
#include "main.h"




int main()
{
	
	
	
	// creates instance of chesswindow
	
	ChessGame ChessWindow;
	ChessWindow.width = 800;
	ChessWindow.height = 800;
	ChessWindow.name = "ChessBoard";
	ChessWindow.size = 100;
	
	// executes the createwindow function from ChessGame class

	ChessWindow.createwindow();
	
		
		

	
	

}


